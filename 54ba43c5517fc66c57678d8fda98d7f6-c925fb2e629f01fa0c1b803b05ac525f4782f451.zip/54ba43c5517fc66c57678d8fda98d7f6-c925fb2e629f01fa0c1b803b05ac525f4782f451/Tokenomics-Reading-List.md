Tokenomics/ Cryptoeconomics/ Token Engineering- these are all buzzwords and that have been getting a lot of [attention lately](https://trends.google.com/trends/explore?date=today%205-y&q=tokenomics,cryptoeconomics,token%20engineering). 

It is a new and emerging domain that has no academic or canonical literature- these blogs/ articles have been a good reference for some general intro into the space. The list is partly based on [awesome](https://github.com/jpantunes/awesome-cryptoeconomics/blob/master/readme.md).


🖋️🔗 Highlighted links are recommended (also labelled `important`)

### Intro
- [Cryptoeconomics for dummies](https://medium.com/@j32804/cryptoeconomics-for-dummies-part-0-7172efa81507)
- ==[Cryptoeconomics 101](https://thecontrol.co/cryptoeconomics-101-e5c883e9a8ff)==`important`
- ==[Making Sense of Cryptoeconomics](https://medium.com/l4-media/making-sense-of-cryptoeconomics-c6455776669) Making Sense of Cryptoeconomics by Josh Stark== `important`
- [What is Cryptoeconomics](https://blockgeeks.com/guides/what-is-cryptoeconomics/) What is Cryptoeconomics, a guide by BlockGeeks
- [How Society Will Be Transformed By Cryptoeconomics](https://media.comakery.com/how-society-will-be-transformed-by-crypto-economics-b02b6765ca8c)
- [Paving the Future of Blockchain Technology](https://hackernoon.com/cryptoeconomics-paving-the-future-of-blockchain-technology-13b04dab971)
- [Vivek Singh's Cryptoeconomics in context](https://hackernoon.com/cryptoeconomics-in-context-6435ad6839be)
- [The Blockchain Economy: A beginner’s guide to institutional cryptoeconomics](https://medium.com/@cryptoeconomics/the-blockchain-economy-a-beginners-guide-to-institutional-cryptoeconomics-64bf2f2beec4) by RMIT Blockchain Innovation Hub
- ==[Cryptoeconomics is Hard Part 1](https://blog.coinfund.io/cryptoeconomics-is-hard-ad401b2428b9), [Part 2](https://blog.coinfund.io/cryptoeconomics-is-hard-part-2-4d522cb3d3a4) and [Part 3](https://blog.coinfund.io/cryptoeconomics-is-hard-market-cap-4833c378a3e0) by Aleksandr Bulkin==`important`
- [Behavioural Crypto-Economics](https://medium.com/berlin-innovation-ventures/behavioral-crypto-economics-6d8befbf2175) the challenge and promise of Blockchain Incentive Design by Elad Verbin
- [Introduction to Blockchain through Cryptoeconomics](https://medium.com/blockchain-at-berkeley/introduction-to-blockchain-through-cryptoeconomics-part-1-bitcoin-369f245067f9) by Zubin Koticha
- [The need for an Incentive scheme in Algorand](https://medium.com/blockchain-at-berkeley/the-need-for-an-incentive-scheme-in-algorand-6fe9db45f2a7) by Alexis Guaba, Zubin Koticha
- [Cryptoeconomics.study](https://cryptoeconomics.study) A free and open source book & course on Cryptoeconomics

  
### Game Theory and Mechanism Design 
#### Game Theory
- [Cryptocurrency Game Theory](https://blockgeeks.com/guides/cryptocurrency-game-theory/) What is Cryptocurrency Game Theory: A Basic introduction

#### Mechanism Design
>"mechanism design is the reverse of game theory"

- [A Crash Course in Mechanism Design for Cryptoeconomic Applications](https://medium.com/blockchannel/a-crash-course-in-mechanism-design-for-cryptoeconomic-applications-a9f06ab6a976)


### Token Engineering
- [The Emergence of Cryptoeconomic Primitives](https://medium.com/@jacobscott/the-emergence-of-cryptoeconomic-primitives-14ef3300cc10)
- ==[History Is Rhyming: Fitness Functions & Comparing Blockchain Tokens To The Web](https://hackernoon.com/history-is-rhyming-fitness-functions-comparing-blockchain-tokens-to-the-web-3c117239f4c) by Simon de la Rouviere== `important`
- ==[Introducing Curation Markets: Trade Popularity of Memes & Information ](https://medium.com/@simondlr/introducing-curation-markets-trade-popularity-of-memes-information-with-code-70bf6fed9881) by Simon de la Rouviere== `important`
- [Can Blockchains Go Rogue?](https://blog.oceanprotocol.com/can-blockchains-go-rogue-5134300ce790) by Trent McConaghy
- [Towards a Practice of Token Engineering](https://blog.oceanprotocol.com/towards-a-practice-of-token-engineering-b02feeeff7ca), with presentation deck [here](https://www.slideshare.net/TrentMcConaghy/towards-a-practice-of-token-engineering) by Trent McConaghy
- [Token Engineering Case Studies](https://blog.oceanprotocol.com/token-engineering-case-studies-b44267e68f4) Analysis of Bitcoin, Design of Ocean Protocol by Trent McConaghy==


### Tokenomics
- [Token sales models](https://vitalik.ca/general/2017/06/09/sales.html) Token sales models by Vitalik Buterin
- [A business guide to Tokenomics](https://medium.com/@wmougayar/tokenomics-a-business-guide-to-token-usage-utility-and-value-b19242053416) by William Mougayar
- [Cryptoasset Valuations](https://medium.com/@cburniske/cryptoasset-valuations-ac83479ffca7) by Chris Burniske
- [Understanding Token Velocity](https://multicoin.capital/2017/12/08/understanding-token-velocity/)
- [On Value, Velocity and Monetary Theory](https://medium.com/blockchannel/on-value-velocity-and-monetary-theory-a-new-approach-to-cryptoasset-valuations-32c9b22e3b6f)
- [The Token Classification Framework](https://www.untitled-inc.com/the-token-classification-framework-a-multi-dimensional-tool-for-understanding-and-classifying-crypto-tokens/) a multi-dimensional tool for understanding and classifying crypto tokens
- [MV = PQ isn't right for crypto](https://medium.com/@AustereCapital/mv-p-que-love-and-circularity-in-the-time-of-crypto-1626c8ac297f) a case made by Austere Capital
- ==[The quantitative theory of money for tokens](https://blog.coinfund.io/the-quantity-theory-of-money-for-tokens-dbfbc5472423) a rebuttal of the MV = PQ theory by Warren Weber== `important`
- [NVT - network value to transactions ratio](https://coinmetrics.io/mtv-ratio-part-ii/) a market to transaction value proposal by Coinmetrics


### Empirical Cryptoeconomics
- [How manipulation-resistant are Prediction Markets?](https://blog.gnosis.pm/how-manipulation-resistant-are-prediction-markets-710e14033d62) How manipulation-resistant are Prediction Markets? Our Undertaking in Empirical Cryptoeconomics by Gnosis
- [Empirical Cryptoeconomics](https://www.reddit.com/r/ethereum/comments/453sid/empirical_cryptoeconomics/) Vitalik Buterin's post on empirical cryptoeconomics
- [Testing mechanism design with AI agents](https://incentivai.co/) Tool for Smart Contract testing with [concept paper](https://incentivai.co/incentivai_concept_paper_10032018.pdf) and [intro](https://medium.com/incentivai/introducing-incentivai-41ce8ba87152)


### Cryptoeconomics
- [Game Theory in Bitcoin](https://www.youtube.com/watch?v=_VANRj3WpdY) Game Theory approach behind the motivation for Bitcoin mining
- [CESC2017 - Cryptoeconomics in Casper](https://youtu.be/5ScY7ruD_eg)
- [What is Cryptoeconomics](https://www.youtube.com/watch?v=9lw3s7iGUXQ) Vlad Zamfir introducing Cryptoeconomics
- [Introduction to Cryptoeconomics](https://www.youtube.com/watch?v=pKqdjaH1dRo) Vitalik Buterin introducing Cryptoeconomics. The corresponding presentation deck is [available here](https://edcon.io/ppt/one/Vitalik%20Buterin_Introduction%20to%20Cryptoeconomics_EDCON.pdf)
- [Hard problems in Cryptoeconomics](https://www.youtube.com/watch?v=p5qwbOkCZSc&t=2316s) Vitalik Buterin discussing hard problems with cryptoeconomics
- [The Cryptoeconomic way](https://www.youtube.com/watch?v=ZH9nMKIHfAE) Vitalik Buterin discussing cryptoeconomics.
- [Cryptoeconomic Protocols In the Context of Wider Society](https://www.youtube.com/watch?v=S47iWiKKvLA) Vitalik Buterin discussing cryptoeconomics. The corresponding presentation deck is [available here](https://www.slideshare.net/ethereum/vitalik-buterin-cryptoeconomic-protocols-in-the-context-of-wider-society)
- [The current state of Cryptoeconomics](https://www.youtube.com/watch?v=u6VSPD5TrP4) The current state of Cryptoeconomics by Vlad Zamfir
- [Programmable Incentives](https://youtu.be/Yo9o5nDTAAQ?t=5h4m44s) by Karl Floersch at Devcon 3
- [Hard problems in cryptoeconomics](https://www.youtube.com/watch?v=p5qwbOkCZSc) by Vitalik Buterin
- [Cryptoeconomic Primitives](https://www.youtube.com/watch?v=Mxt-SdfXEKw&t=1598s)
- [Global Scale Research Networks and Cryptoeconomics](https://www.youtube.com/watch?v=G9Bp56y3X8U)
- [Towards a Practice of Token Engineering](https://www.youtube.com/watch?v=Zf-WlBl1dAA) by Trent McConaghy
- [Cryptoeconomic Theory](https://medium.com/@viktorwrites/cryptoeconomic-theory-table-of-contents-311fcf30bc2b) [part 1](https://medium.com/blockchannel/cryptoeconomic-theory-basics-of-social-order-2be4c1be89c1), [part 2](https://medium.com/blockchannel/cryptoeconomic-theory-markets-vs-planning-85a76bb2c038), [part 3](https://medium.com/blockchannel/cryptoeconomic-theory-pareto-efficiency-89d34664f9d) and [part 4](https://medium.com/blockchannel/cryptoeconomic-theory-game-theory-basics-fb3a49aab1a8) an on-going series by Viktor Makarskyy

### Network Effects
- [A Note on Metcalfe's Law, Externalities and Ecosystem Splits](https://vitalik.ca/general/2017/07/27/metcalfe.html) by Vitalik Buterin
- ==[Continuous Token Models: Towards a Million Networks of Value](https://media.consensys.net/exploring-continuous-token-models-towards-a-million-networks-of-value-fff153175776) by Simon de la Rouviere== `important`
- [Crypto Tokens: A breakthrough in open network design](https://medium.com/@cdixon/crypto-tokens-a-breakthrough-in-open-network-design-e600975be2ef) by Chris Dixon


### Consensus Mechanisms
#### PoW - Proof of Work
- [PoW and Blockchains](https://www.zurich.ibm.com/dccl/papers/eyal_dccl_slides.pdf) presentation by Prof. Ittay Eyal (IC3)
- [An Economic Analysis of Difficulty Adjustment Algorithms in PoW Blockchain Systems](https://www.ssrn.com/abstract=3410460) by Noda et al.
- [ConsensusPedia - An Encylopedia of 29 consensus algorithms](https://hackernoon.com/consensuspedia-an-encyclopedia-of-29-consensus-algorithms-e9c4b4b7d08f) article by Vasa
- [Proof of Work vs Proof of Stake](https://blockgeeks.com/guides/proof-of-work-vs-proof-of-stake/) by BlockGeeks
- [Vulnerability: Proof of Work vs. Proof of Stake](https://medium.com/@robertgreenfieldiv/vulnerability-proof-of-work-vs-proof-of-stake-f0c44807d18c)

#### PoS - Proof of Stake
- ==[Strengths and Weaknesses of PoS](https://blog.ethereum.org/2014/07/05/stake/) Vitalik Buterin's article on the strengths and weaknesses of staking contrasting to PoW algorithms  ==`important`
- ==[The evolution of PoS](https://cointelegraph.com/news/the-history-and-evolution-of-proof-of-stake) Article on the evolution of PoS by Coin Telegraph== `important`
- [The History of Casper - Chapter 1](https://medium.com/@Vlad_Zamfir/the-history-of-casper-part-1-59233819c9a9), [Chapter 2](https://medium.com/@Vlad_Zamfir/the-history-of-casper-chapter-2-8e09b9d3b780), [Chapter 3](https://medium.com/@Vlad_Zamfir/the-history-of-casper-chapter-3-70fefb1182fc), [Chapter 4](https://medium.com/@Vlad_Zamfir/the-history-of-casper-chapter-4-3855638b5f0e),
- [Chapter 5](https://medium.com/@Vlad_Zamfir/the-history-of-casper-chapter-5-8652959cef58) Vlad Zamfir's series on the history of Casper
- [Critic on the PoS Philosophy](https://medium.com/@tuurdemeester/critique-of-buterins-a-proof-of-stake-design-philosophy-49fc9ebb36c6) by Tuur Demeester
- [Extended Summary on Casper](https://medium.com/@jonchoi/ethereum-casper-101-7a851a4f1eb0) by Jon Choi
- [The Economics of the PoS consensus algorithm](https://medium.com/@gertrammeloo/the-economics-of-the-proof-of-stake-consensus-algorithm-e28adf63e9db)
